KGEN 12345 V9.2.0 LAYOUT FINAL POLISH

放檔：
- index_12345_Heart_UI_V9_2_0_LAYOUT_FINAL_POLISH.html 改名 index.html，放 K線西遊記/temples/12345/
- 12345.html 放 repo 根目錄
- wallet-12345.html 放 repo 根目錄

修正：
- 先改 VERSION / BUILD / CHANGELOG，再修程式。
- GA Evolution 移到中上空白區，不壓 K 線圖。
- 左下四個隱藏功能鍵重建為唯一一列，不再與底部八鍵重複。
- 底部八鍵重排，右下命名為「右側神規」，控制右下資訊區塊收合。
- 曲速引擎上移，避開方向盤。
- 跨年倒數改分鐘級固定顯示，不每秒閃爍。
- 不動錢包連線核心。
